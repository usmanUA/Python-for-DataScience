def count_in_list(lst, s):
    ''' doc '''

    return len([word for word in lst if word == s])
